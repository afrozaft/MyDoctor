<?php 
include "connection.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Contact us</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel="icon" href="d.png" type="image/gif/png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
	<style>
			body{
			background-color: lightblue;
		}
		nav{
			margin-bottom: 20px;
		}
		#logo{
			font-size: 40px;
			margin-right: 40px;
			font-family:  serif;
			
		}
		nav a{
			font-size: 20px;
			margin-left: 20px;
		}
		*{
			margin: 0;
			padding: 0;
			
			font-family: 'Courgette', sans-serif;
		}
		#main-img{
	background-image:linear-gradient(rgba(0,115,153,0.5),rgba(0,115,153,0.5)),url(co.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	
	
    width: 100%;
    
	height: 100vh;

}


#recommended{
	margin-bottom: 50px;
}


	</style>

</head>
<body>
	<header>
	<!-- Header of the page -->
	<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
		  <a class="navbar-brand" id="logo" href="index.php" style="color: #0F82FF;">My<span><img src="d.png"></span>Doctor.com</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav mx-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="doctor.php">Doctors</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="clinic.php">Clinics</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="diagnostic.php">Diagnostics</a>
		      </li>
		      <li class="nav-item active">
		        <a class="nav-link" href="contact.php">Contact us<span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about.php">About us</a>
		      </li>
		    </ul>
		    <form class="form-inline my-2 my-lg-0">
		      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
		      <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
		    </form>
		  </div>
  </nav>
		
	</header>

	<main>
		<div class="img-fluid" id="main-img">
			
		</div>

		<!-- ///////////// Insert Of Message ////////////// -->
			<?php 
			
				if($_POST['sub'])
				{
					$name   = $_POST['name'];
					$email  = $_POST['email'];
					$phone  = $_POST['phone'];
					$msg	= $_POST['msg'];

					$sql = "insert into `contact`(`id`,`name`,`email`,`phone`,`msg`)values('','$name','$email','$phone','$msg')";

					mysqli_query($db,$sql);

				}

			?>
<!-- /////////////////////////////////////////////////// -->


		 <!-- Contact Us  -->
     <section>
     	<div class="container mb-5">
			<h1 class="text-center text-capitalize pt-5">Contact Us</h1>
			<hr class="w-25 mx-auto pt-5">

			 <div class="modal-body w-50 mx-auto">
				        	<form action="" method="post">
								  <div class="form-group">
								    <label for="name">Name:</label>
								    <input type="text" class="form-control" name="name">
								  </div>
								  <div class="form-group">
								    <label for="email">Email:</label>
								    <input type="email" class="form-control" name="email" autocomplete="off">
								  </div>
								  <div class="form-group">
								    <label for="phone">Phone:</label>
								    <input type="text" class="form-control" name="phone">
								  </div>
								  <div class="form-group">
								  	<label for="msg">Message:</label>
								  	<textarea class="form-control" name="msg"></textarea>
								  </div>
								  <div class="form-group form-check">
								    <label class="form-check-label">
								      <input class="form-check-input" type="checkbox"> Remember me
								    </label>
								  </div>
								  <input type="submit" class="btn btn-primary w-25" name="sub" value="Send">
								</form>
				          
				        </div>
		   </section>

<?php include "links.php"?>


	 	
		


	</main>

<footer>
	<?php include "footer.php"?>
</footer>
	  



	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>	