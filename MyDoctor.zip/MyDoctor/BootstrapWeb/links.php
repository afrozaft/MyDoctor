<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	<link rel="icon" href="d.png" type="image/gif/png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
	<style>
			#mySidenav a {
  position: absolute;
  left: -40px;
  transition: 0.3s;
  padding: 15px;
  width: 80px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  border-radius: 0 30px 30px 0;
}

#mySidenav a:hover {
  left: 0;
}

#whatsapp {
  top: 20px;
  background-color: #4CAF50;
  
}

#facebook {
  top: 90px;
  background-color: #2196F3;
}

#google {
  top: 160px;
  background-color: #f44336;
}

#gethub {
  top: 230px;
  background-color: #555
}

.sidenav{
	position: fixed;
	top: 190px;
}

	</style>

</head>
<body>

	 <!-- Sidenav Start -->
			<div id="mySidenav" class="sidenav">
			  <a href="#" id="whatsapp"><i class="fab fa-whatsapp fa-1x"></i></a>
			  <a href="#" id="facebook"><i class="fab fa-facebook-f fa-1x"></i></a>
			  <a href="#" id="google"><i class="fab fa-google-plus fa-1x"></i></a>
			  <a href="#" id="gethub"><i class="fab fa-github fa-1x"></i></a>
			</div>
	<!-- Sidenav End -->

	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>

</body>
</html>