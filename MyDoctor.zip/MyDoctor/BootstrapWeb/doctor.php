<?php 
include "connection.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Doctors</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	<link rel="icon" href="d.png" type="image/gif/png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
	<style>
			body{
			background-color: lightblue;
		}
		nav{
			margin-bottom: 20px;
		}
		#logo{
			font-size: 40px;
			margin-right: 40px;
			font-family:  serif;
			
		}
		nav a{
			font-size: 20px;
			margin-left: 20px;
		}
		*{
			margin: 0;
			padding: 0;
			
			font-family: 'Courgette', sans-serif;
		}
		#main-img{
	background-image:linear-gradient(rgba(0,115,153,0.5),rgba(0,115,153,0.5)),url(d1.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	
	
    width: 100%;
    
	height: 100vh;

}


/*//////////////  Doctors List CSS CODE   ////////////*/
.doc{
	position: relative;
	
	left: 12%;
	
	background-color: white;
	border-radius:25px ;
	width: 75%;
	height: 50%;
	
	margin-bottom: 5%;
   
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.doc i{
	
	position: relative;
	left: 45%;
	top: 5px;
}
	
.doc p{
	margin: 10px;
	position: relative;
	left: 4%;
	top: 2%;
	margin-left: 5%;
	margin-bottom: 10px;
   }
#recommended{
	margin-bottom: 50px;
}

	</style>

</head>
<body>
	<header>
	<!-- Header of the page -->
	<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
		  <a class="navbar-brand" id="logo" href="index.php" style="color: #0F82FF;">My<span><img src="d.png"></span>Doctor.com</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav mx-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Home</a>
		      </li>
		      <li class="nav-item active">
		        <a class="nav-link" href="doctor.php">Doctors<span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="clinic.php">Clinics</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="diagnostic.php">Diagnostics</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact.php">Contact us</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about.php">About us</a>
		      </li>
		    </ul>
		    <form class="form-inline my-2 my-lg-0">
		      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
		      <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
		    </form>
		  </div>
  </nav>
		
	</header>

	<main>
		<div class="img-fluid" id="main-img">
			
		</div>

		<section>
			      <!--  Recommended Doctors  -->
   
		  <div class="container-fluid" id="recommended">
			<h1 class="text-center text-capitalize pt-5">Recommended Doctors</h1>
			<hr class="w-25 mx-auto pt-5">
         	<div class="row">
         	<div class="col-lg-12 col-md-12 col-sm-12 col-12">



<!-- //////////// Doctors List Using PHP & MYSQL //////////////// -->
     
      	<div class="list">
        <?php 
         $s = "select * from `doctor`";
         $q = mysqli_query($db,$s);
         $num = mysqli_num_rows($q);
         for($i=1;$i<=$num;$i++)
         {	
         	
            $l = mysqli_fetch_array($q);
           
           
            print"  <div class='doc'>
                    <i class='fas fa-user-md fa-7x'></i><hr>
                    <p>Name:  $l[dname]</p>
                    <p>Degree:  $l[ddegree]</p>
                    <p>Specialist:  $l[dspecialist]</p>
                    <p>Hospital:  $l[dhospital]</p>
                    <p>Clinic:  $l[dclinic]</p>
                    <p>Day:  $l[dday]</p>
                    <p>Time:  $l[dtime]</p>
                    <p>Fees:  $l[dfee]</p>
                    <p>Location:  $l[daddress]</p>
                    <p>Contact:  $l[dcontact]</p>
                </div>";
               
      } ?>    
      	</div> 
 		</div>
 		</div>
 		</div>
		</section>

 
<!--/////////////// END //////////////////// -->
	<?php include "links.php"?> 	
		


	</main>

<footer>
	<?php include "footer.php"?>
</footer>
	  



	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>	