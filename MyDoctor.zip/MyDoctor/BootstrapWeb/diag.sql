-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2019 at 06:55 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `diag`
--

CREATE TABLE `diag` (
  `diag_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `diag`
--

INSERT INTO `diag` (`diag_id`, `name`, `address`, `contact`) VALUES
(7, ' Future Healthcare And Diagnostics Centre', '90, Kalitala Road, Prince Anwar Shah Road Connector,Kolkata\r\nKalika, Kolkata', '033 4058 6272'),
(8, ' Atulya Diagnostics And Polyclinic', '41-A, S. P. Mukherjee Road Near Chittaranjan Cancer Hospital,kolkata Bhawanipore, Kolkata', '033 3085 9219'),
(9, 'Pulse Diagnostics Pvt. Ltd.', 'Kalighat, Kolkata - 700026', '919883021926'),
(10, 'Kuruvilla Diagnostics', 'Behala, Kolkata - 700034', '919883030822'),
(11, 'Chittaranjan Hospital', 'Beniapukur, Kolkata - 700014', '919883027598'),
(12, 'Apollo Diagnostics', 'Park Street, Kolkata - 700016', '919883028425'),
(13, 'SEBA Blood Collection Centre & Poly Clinic', 'Bonhooghly, Kolkata - 700090', '919883021957'),
(14, 'Divine Diagnostic Laboratory & Polyclinic', 'Sonarpur, Kolkata - 700150', '919883031864'),
(15, 'Allergy Asthma Center', 'Entally, Kolkata - 700014', '919883013685'),
(16, 'Kaji Abdul Rasif', 'Barasat, Kolkata - 700125', '919883017670'),
(17, 'Kolkata Electrodiagnostic Centre', 'Dhakuria, Kolkata - 700031', '919883023953'),
(18, 'Patient Planet', 'Kasba, Kolkata - 700107', '+919883037132'),
(19, 'Meditips Solution LLP', 'New Town, Kolkata - 700156', '+919883027283'),
(20, 'Extemplo Medicinal Services Pvt. Ltd.', 'Salt Lake City, Kolkata - 700102', '+919883024662'),
(21, 'Sanjanas Treatment Center', 'Dum Dum, Kolkata - 700028', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diag`
--
ALTER TABLE `diag`
  ADD PRIMARY KEY (`diag_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diag`
--
ALTER TABLE `diag`
  MODIFY `diag_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
