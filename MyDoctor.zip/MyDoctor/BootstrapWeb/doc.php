<?php 
$db = mysqli_connect("localhost","root","","mydatabase");





?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Doc</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<style type="text/css">
		
	.doc{
	position: relative;

	left: 10px;
	
	border-radius:25px ;
	width: 720px;
	height: 420px;
	float: left;
	margin: 15px;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.doc i{
	align-items: center;
	position: relative;
	left: 300px;
	top: 5px;
}
	
.doc p{
	margin: 5px;
	position: relative;
	left: 15px;
	top: 20px;

}

/*.card{
			width:300px; 
			height:350px;
			border-radius: 25px;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			float: left;

		}*/
	</style>

</head>
<body>
		<?php 
         $s = "select * from `doctor`";
         $q = mysqli_query($db,$s);
         $num = mysqli_num_rows($q);

        for($i=1;$i<=$num;$i++)
         {	
         	
            $l = mysqli_fetch_array($q);
            ?>
           
               <div class='doc'>
                    <i class='fas fa-user-md fa-7x'></i><hr>
                    <p>Name:<?php print"$l[dname]"?></p>
                    <p>Degree:<?php print"$l[ddegree]"?></p>
                    <p>Specialist:<?php print"$l[dspecialist]"?></p>
                    <p>Hospital:<?php print"$l[dhospital]"?></p>
                    <p>Clinic:<?php print"$l[dclinic]"?></p>
                    <p>Day:<?php print"$l[dday]"?></p>
                    <p>Time:<?php print"$l[dtime]"?></p>
                    <p>Fees:<?php print"$l[dfee]"?></p>
                    <p>Location:<?php print"$l[daddress]"?></p>
                    <p>Contact:<?php print"$l[dcontact]"?></p>
                </div>
               
        <?php } ?>   
	 		<div>	   
            <?php include "footer.php"?> 
           </div>
	<script type="text/javascript" src="js/jquery.js"></script>
   <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>	