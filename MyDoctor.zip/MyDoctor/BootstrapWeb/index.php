<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel="icon" href="d.png" type="image/gif/png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
	

	
	<style type="text/css">
		body{
			background-color: lightblue;
		}
		nav{
			margin-bottom: 20px;
		}
		#logo{
			font-size: 40px;
			margin-right: 40px;
			font-family:  serif;
			
		}
		nav a{
			font-size: 20px;
			margin-left: 20px;
		}
		*{
			margin: 0;
			padding: 0;
			
			font-family: 'Courgette', sans-serif;
		}
		#mySidenav a {
  position: absolute;
  left: -40px;
  transition: 0.3s;
  padding: 15px;
  width: 80px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  border-radius: 0 30px 30px 0;
}

#mySidenav a:hover {
  left: 0;
}

#whatsapp {
  bottom: 2280px;
  background-color: #4CAF50;
  
}

#facebook {
  bottom: 2210px;
  background-color: #2196F3;
}

#google {
  bottom: 2140px;
  background-color: #f44336;
}

#gethub {
  bottom: 2070px;
  background-color: #555
}


		.slider{
			margin-top: 92px;
		}
        #msg{
        	height: 200px;
        }
        /* Loader*/
        #loader{
        	position: fixed;
        	width: 100%;
        	height: 100vh;
        	background: #fff url('bob.gif') no-repeat center;
        	z-index: 99999;
		
		}  

	
		#content{
			display: none;
		}
		.ani{
			position: relative;
			-webkit-animation-name: doc;
			-webkit-animation-duration: 1s;
			animation-name: doc;
			animation-duration: 1s;

		}
		@-webkit-keyframes doc{
			from{bottom: -100px; opacity: 0;}
			to{bottom: 0px; opacity: 1;}
		}
		@keyframes doc{
			from{bottom: -100px; opacity: 0;}
			to{bottom: 0px; opacity: 1;}
		}

		.card{
			width:300px; 
			height:350px;
			border-radius: 25px;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

		}
	</style>
        
	

</head>
<body onload="myfunction()">
	<div id="loader">
		
	</div>
	<div id="content" class="ani">
	<header>
	<!-- Header of the page -->
	<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
		  <a class="navbar-brand" id="logo" href="index.php" style="color: #0F82FF;">My<span><img src="d.png"></span>Doctor.com</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav mx-auto">
		      <li class="nav-item active">
		        <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="doctor.php">Doctors</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="clinic.php">Clinics</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="diagnostic.php">Diagnostics</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact.php">Contact us</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about.php">About us</a>
		      </li>
		    </ul>
		    <form class="form-inline my-2 my-lg-0">
		      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
		      <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
		    </form>
		  </div>
  </nav>
		
	</header>
	
	<main>
		<section><!-- Slider -->
        <div class="slider">
		<div id="myCarousel" class="carousel slide" data-ride="carousel">
		  <ol class="carousel-indicators">
		    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		    <li data-target="#myCarousel" data-slide-to="1"></li>
		    <li data-target="#myCarousel" data-slide-to="2"></li>
		    <li data-target="#myCarousel" data-slide-to="3"></li>
		    <li data-target="#myCarousel" data-slide-to="4"></li>
		  </ol>	
		  <div class="carousel-inner">
		    <div class="carousel-item active">
		      <img class="d-block w-100" src="1.jpg" alt="First slide">
		      <div class="carousel-caption d-none d-md-block">
			    <h1 class="text-primary">Best Doctors</h1>
			    <h5 class="text-success">Near Your Location</h5>
			  </div>
		    </div>
		    <div class="carousel-item">
		      <img class="d-block w-100" src="2.jpg" alt="Second slide">
		      <div class="carousel-caption d-none d-md-block">
			    <h1 class="text-primary">Easy Diagonsis</h1>
			    <h5 class="text-success">Near Your Location</h5>
			  </div>
		    </div>
		    <div class="carousel-item">
		      <img class="d-block w-100" src="3.jpg" alt="Third slide">
		      <div class="carousel-caption d-none d-md-block">
			    <h1 class="text-primary">Your's Doctors Your's Friend</h1>
			    <h5 class="text-success">Choose Your Right Doctors</h5>
			  </div>
		    </div>
		     <div class="carousel-item">
		      <img class="d-block w-100" src="dg1.jpg" alt="Third slide">
		      <div class="carousel-caption d-none d-md-block">
			    <h1 class="text-primary">Your health is important for us</h1>
			    <h5 class="text-success">Health is the greatest possession</h5>
			  </div>
		    </div>
		    <div class="carousel-item">
		      <img class="d-block w-100" src="dg2.jpg" alt="Third slide">
		      <div class="carousel-caption d-none d-md-block">
			    <h1 class="text-primary">Sickness is mankind's greatest defect</h1>
			    <h5 class="text-success">Maintaining good health should be the primary focus of everyone</h5>
			  </div>
		    </div>
		     <div class="carousel-item">
		      <img class="d-block w-100" src="5.jpg" alt="Third slide">
		      <div class="carousel-caption d-none d-md-block">
			    <h1 class="text-primary">Best Clinics</h1>
			    <h5 class="text-success">Find Clinics NearBy You</h5>
			  </div>
		    </div>
		  </div>
		  <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
		    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
		    <span class="carousel-control-next-icon" aria-hidden="true"></span>
		    <span class="sr-only">Next</span>
		  </a>
		</div>
      </div>
    </section>  


    <section><!-- About Us -->
		<div class="container-fluid">
			<h1 class="text-center text-capitalize pt-5">About Us</h1>
			<hr class="w-25 mx-auto pt-5">

			<div class="row mb-5">
				<div class="col-lg-6 col-md-6 col-12">
					<img src="7.jpg" class="img-fluid">
				</div>
				<div class="col-lg-6 col-md-6 col-12">
					<h1>Our Aim ?</h1>
					<hr>
					<p>Your home for health
For millions of people, MyDocter is the trusted and familiar home where they know they’ll find a good healing touch. It connects them with everything they need to take good care of themselves and their family - assessing health issues, finding the right doctor, booking diagnostic tests, obtaining medicines, storing health records or learning new ways to live healthier.<br>

Healthcare providers can also harness the power of MyDoctor as the definitive platform that helps them build their presence, grow establishments and engage patients more deeply than ever.</p>
					<a href="about.php"><button class="btn btn-primary">Know more</button></a>
				</div>
				
			</div>
			
		</div>    	


    </section>

    <section><!-- Cards -->
    	<div class="container">
			<h1 class="text-center text-capitalize pt-5">Services</h1>
			<hr class="w-25 mx-auto pt-5">

   
    <div class="row text-center">
      <div class="col-lg-4 col-md-4 col-12">
    	<div class="card">
		  <img class="card-img-top" src="6.jpg" alt="Card image cap">
		  <div class="card-body">
		    <h5 class="card-title">Doctors</h5>
		   <p class="card-text">A teacher must believe in the value and interest of his subject as a doctor believes in health.</p>
		    <a href="doctor.php" class="btn btn-primary">Go Details </a>
		  </div>
       </div>
      </div> 

      <div class="col-lg-4 col-md-4 col-12">
    	<div class="card">
		  <img class="card-img-top" src="6.jpg" alt="Card image cap">
		  <div class="card-body">
		    <h5 class="card-title">Clinics</h5>
		    <p class="card-text">To array a man's will against his sickness is the supreme art of medicine.</p>
		    <a href="clinic.php" class="btn btn-primary">Go Details </a>
		  </div>
       </div>
      </div> 
      
      <div class="col-lg-4 col-md-4 col-12">
    	<div class="card">
		  <img class="card-img-top" src="6.jpg" alt="Card image cap">
		  <div class="card-body">
		    <h5 class="card-title">Diagnostics</h5>
		    <p class="card-text">Eastern medicine is not about curing your sickness. It's about keeping you well.</p>
		    <a href="diagnostic.php" class="btn btn-primary">Go Details </a>
		  </div>
       </div>
      </div> 
  </div>
  </div>	

    </section>
     <!-- contact -->
    <section class="bg-primary text-white mt-5">
    	
    	<article class="py-5 text-center">
    		<div>
    			<h3 class="dispaly-4">+91 0123456789</h3>
    			<p>Call immediately your health is important for us.</p>
               <a href="contact.php"><button class="btn btn-warning">Contact Now</button></a>
    			
    		</div>
    	</article>
    </section>

    <!-- Sidenav End -->
	<div id="mySidenav" class="sidenav">
	  <a href="#" id="whatsapp"><i class="fab fa-whatsapp fa-1x"></i></a>
	  <a href="#" id="facebook"><i class="fab fa-facebook-f fa-1x"></i></a>
	  <a href="#" id="google"><i class="fab fa-google-plus fa-1x"></i></a>
	  <a href="#" id="gethub"><i class="fab fa-github fa-1x"></i></a>
	</div>
	<!-- Sidenav End --> 


    <section><!-- Gallery -->
    	<div class="container">
			<h1 class="text-center text-capitalize pt-5">Gallery</h1>
			<hr class="w-25 mx-auto pt-5">
           <div class="row">
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-user-md fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Dr. Anish Bharti</h4>
				      <p class="card-text">Specialist in Dentist</p>
				      <a href="doctor.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-user-md fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Dr. Ranjit Chakraborti</h4>
				      <p class="card-text">Specialist in Gynecologist</p>
				      <a href="doctor.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-user-md fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Dr. Kallol Paul</h4>
				      <p class="card-text">Specialist in Otorhinolaryngologist</p>
				      <a href="doctor.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-clinic-medical fa-5x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Fortis Hospital</h4>
				      <p class="card-text">730, Eastern Metropolitan Bypass, Anandapur Near Ruby, kolkata</p>
				      <a href="clinic.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-clinic-medical fa-5x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Uro Square</h4>
				     <p class="card-text">12-D, Krishnakunja Apartment, Ballygunge Station Road, Kolkata</p>
				      <a href="clinic.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-clinic-medical fa-5x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Indopath Clinical</h4>
				      <p class="card-text">87,Near Elgin Road & P.C. Chandra Jewellers, Kolkata</p>
				      <a href="clinic.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-heartbeat fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Kuruvilla Diagnostics</h4>
				      <p class="card-text">Behala, Kolkata - 700034</p>
				      <a href="diagnostic.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-heartbeat fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Apollo Diagnostics</h4>
				      <p class="card-text">Park Street, Kolkata - 700016</p>
				      <a href="diagnostic.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card">
				    <i class="card-img-top rounded-circle mx-auto pt-1 fas fa-heartbeat fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Meditips Solution LLP</h4>
				      <p class="card-text">New Town, Kolkata - 700156</p>
				      <a href="diagnostic.php" class="btn btn-primary stretched-link">See Profile</a>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
       </div>

    	
    </section>
    <!-- Join -->
	<section class="bg-primary">
		<article class="py-5">
			<div class="text-center text-white">
				<h3 class="dispaly-4">Want To Join</h3>
				<p>Join Our Hand And Make Our Society Be healthy.</p>
				<button class="btn btn-warning" data-toggle="modal" data-target="#myModal">Join Now</button>
			</div>

			<!-- The Modal -->
				  <div class="modal fade" id="myModal">
				    <div class="modal-dialog modal-dialog-centered">
				      <div class="modal-content">
				      
				        <!-- Modal Header -->
				        <div class="modal-header">
				          <h4 class="modal-title">Sign Up</h4>
				          <button type="button" class="close" data-dismiss="modal">&times;</button>
				        </div>
				        
				        <!-- Modal body -->
				        <div class="modal-body">
				        	<form action="/action_page.php">
								  <div class="form-group">
								    <label for="email">Email address:</label>
								    <input type="email" class="form-control" id="email" autocomplete="off">
								  </div>
								  <div class="form-group">
								    <label for="pwd">Password:</label>
								    <input type="password" class="form-control" id="pwd">
								  </div>
								  <div class="form-group form-check">
								    <label class="form-check-label">
								      <input class="form-check-input" type="checkbox"> Remember me
								    </label>
								  </div>
								  <button type="submit" class="btn btn-primary">Submit</button>
								</form>
				          
				        </div>
				        
				        <!-- Modal footer -->
				        <div class="modal-footer">
				          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				        </div>
				        
				      </div>
				    </div>
				  </div>
		</article>
	</section>
     
<!-- ///////////// Insert Of Message ////////////// -->
			<?php 
			
				if($_POST['sub'])
				{
					$name   = $_POST['name'];
					$email  = $_POST['email'];
					$phone  = $_POST['phone'];
					$msg	= $_POST['msg'];

					$sql = "insert into `contact`(`id`,`name`,`email`,`phone`,`msg`)values('','$name','$email','$phone','$msg')";

					mysqli_query($db,$sql);

				}

			?>
<!-- /////////////////////////////////////////////////// -->


		 <!-- Contact Us  -->
     <section>
     	<div class="container mb-5">
			<h1 class="text-center text-capitalize pt-5">Contact Us</h1>
			<hr class="w-25 mx-auto pt-5">

			 <div class="modal-body w-50 mx-auto">
				        	<form action="" method="post">
								  <div class="form-group">
								    <label for="name">Name:</label>
								    <input type="text" class="form-control" name="name">
								  </div>
								  <div class="form-group">
								    <label for="email">Email:</label>
								    <input type="email" class="form-control" name="email" autocomplete="off">
								  </div>
								  <div class="form-group">
								    <label for="phone">Phone:</label>
								    <input type="text" class="form-control" name="phone">
								  </div>
								  <div class="form-group">
								  	<label for="msg">Message:</label>
								  	<textarea class="form-control" name="msg"></textarea>
								  </div>
								  <div class="form-group form-check">
								    <label class="form-check-label">
								      <input class="form-check-input" type="checkbox"> Remember me
								    </label>
								  </div>
								  <input type="submit" class="btn btn-primary w-25" name="sub" value="Send">
								</form>
				          
				        </div>
		   </section>



	</main>

		<!-- Footer -->
<footer class="page-footer font-small bg-dark text-white">

    <div style="background-color: #6351ce;">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">Get connected with us on social networks!</h6>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right">

            <!-- Facebook -->
            <a class="fb-ic">
              <i class="fab fa-facebook-f white-text mr-4"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic">
              <i class="fab fa-twitter white-text mr-4"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic">
              <i class="fab fa-google-plus-g white-text mr-4"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic">
              <i class="fab fa-linkedin-in white-text mr-4"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic">
              <i class="fab fa-instagram white-text"> </i>
            </a>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5 ">

      <!-- Grid row -->
      <div class="row mt-3">

        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

          <!-- Content -->
          <h6 class="text-uppercase font-weight-bold">MyDoctor.com</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; border-bottom: 1px solid #6351ce;">
          <p>Healthcare providers can also harness the power of MyDoctor as the definitive platform that helps them build their presence, grow establishments and engage patients more deeply than ever.</p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Services</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; border-bottom: 1px solid #6351ce;">
          <p>
            <a href="doctor.php" style="color: white;">Doctors</a>
          </p>
          <p>
            <a href="clinic.php" style="color: white;">Clinics</a>
          </p>
          <p>
            <a href="diagnostic.php" style="color: white;">Diagnostics</a>
          </p>
          <p>
            <a href="about.php" style="color: white;">About us</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Support</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; border-bottom: 1px solid #6351ce;">
          <p>
            <a href="#" style="color: white;">Emergency 24x7</a>
          </p>
          <p>
            <a href="#" style="color: white;">Medical Shops</a>
          </p>
          <p>
            <a href="#" style="color: white;">Diagnostics Test</a>
          </p>
          <p>
            <a href="#" style="color: white;">Help</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Contact</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px; border-bottom: 1px solid #6351ce;">
          <p>
            <i class="fas fa-home mr-3"></i> Newtown, Kolkata, India</p>
          <p>
            <i class="fas fa-envelope mr-3"></i> helpmydoctorin@gmail.com</p>
          <p>
            <i class="fas fa-phone mr-3"></i> +91 0123456789</p>
         

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div style="background-color: #212529;color: grey;">
    <div class="footer-copyright text-center py-3">© 2019 Copyright :
      <a href="index.php" style="color: grey;"> MyDoctor.com</a>  All Rights Reserved
    </div>
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->





  

</div>
	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script>
    	

    	var start;
    	function myfunction(){
    		start = setTimeout(showpage,2500);
    	}

    	function showpage(){
    		document.getElementById("loader").style.display="none";
    		document.getElementById("content").style.display="block";
    	}
    </script>

</body>
</html>	