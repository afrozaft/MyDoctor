-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2019 at 06:55 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `d_id` int(11) NOT NULL,
  `dname` text NOT NULL,
  `ddegree` text NOT NULL,
  `dspecialist` text NOT NULL,
  `daddress` varchar(100) NOT NULL,
  `dhospital` varchar(50) NOT NULL,
  `dclinic` text NOT NULL,
  `dday` varchar(100) NOT NULL,
  `dtime` varchar(50) NOT NULL,
  `dfee` int(11) NOT NULL,
  `dcontact` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`d_id`, `dname`, `ddegree`, `dspecialist`, `daddress`, `dhospital`, `dclinic`, `dday`, `dtime`, `dfee`, `dcontact`) VALUES
(10, ' Dr. Arimeeta Bhadra', 'BDS, MDS - Oral & Maxillofacial Surgery', 'Dentist', 'B-1, New Town Metro Plaza, Rajarhat Road, Chinnar Park, Aatghara, Kolkata', '', 'Teeth Care Multispeciality Dental Clinic', 'Mon, Thu, Sun', '10:30 AM - 1:00 PM, 4:00 PM - 8:00 PM', 200, '033 4058 6594'),
(11, ' Dr. Sanket Chakraverty', 'BDS, MDS - Prosthodontics', 'Dentist', 'B-1, New Town Metro Plaza, Rajarhat Road, Chinnar Park, Aatghara, Kolkata', '', 'Teeth Care Multispeciality Dental Clinic', 'Wed, Fri, Sat', '10:00 AM - 1:00 PM , 4:00 PM - 8:00 PM', 200, '03340586594'),
(12, ' Dr. Deepan Chandra', 'MDS - Periodontology and Oral Implantology, BDS, Periodontist, Cosmetic/Aesthetic Dentist', 'Dentist', '529/J, Mahatma Gandhi Road, Opp. MORE store, Behind Ranisha Beauty Parlour, Kolkata', '', 'Smilecare Dental Clinic', 'Mon, Sat', '9:00 AM - 1:00 PM , 6:30 PM - 10:30 PM', 400, '03340586572'),
(13, 'Dr. Anish Bharti', 'BDS, MDS - Prosthodontist And Crown Bridge,  Prosthodontist, Dentist', 'Dentist', 'AL-16, Sector-2, Near Tank Number-8, Kolkata', '', 'Implanting Smile', 'Tue', '12:30 PM - 3:00 PM', 300, '03340586594'),
(14, ' Dr. Subrata Das', 'BDS  Dental Surgeon, Cosmetic/Aesthetic Dentist', 'Dentist', 'Deben Sen Road, Tara Pukur South, Near State Eclectic Office, Agarpara, kolkata', '', 'Smile Line Dental Clinic', 'Mon-Sat', '5:00 PM - 9:00 PM', 100, '03340586227'),
(15, ' Dr. Narayan Banerjee', 'MBBS, MD - Medicine', 'General Physician', '730, Eastern Metropolitan Bypass, Anandapur, Near Ruby, Kolkata', 'Fortis Hospital ', '', 'On Call', '', 1000, '08048885819'),
(16, ' Dr. S. B. Nagori', 'MD - General Medicine, MBBS', 'General Physician', '114B, Sarat Bose Rd, Dover Terrace, Opp: Ramakrishna Mission Seva Pratishthan, Kolkata', 'Calcutta Heart Research Centre', '', 'Mon-Sat', '9:00 AM - 11:00 AM, 5:00 PM - 7:00 PM', 1000, '03340586594'),
(17, 'Dr. Debdutta Banerjee', 'MBBS, MD - Community Medicine', 'General Physician', '1, Mall Road, Dum Dum, Near Nager Bazar Flyover, Kolkata', 'ILS Hospitals', '', 'On Call', '', 1000, ''),
(18, 'Dr. Parag Ranjan Chakraborty', 'MBBS, DNB - Nephrology', 'General Physician, Nephrologist/Renal Specialist', 'Pustak Apartments, Parnasree Pally, Near Parnasree College, Kolkata-700060', '', 'Bharat Kesari Clinic', 'Mon-Sat', '10:00 AM - 1:00 PM, 8:00 PM - 10:00 PM', 350, ''),
(20, ' Dr. Koelina Sil', ' MD - General Medicine, MBBS', 'Internal Medicine, Consultant Physician', '493, Purbaloke,Near metro wholesale store, Kolkata', '', 'Dr. Koelina Sil Clinic', 'Mon, Wed-Sat', '7:00 AM - 8:00 AM, 8:00 PM - 10:00 PM', 500, ''),
(21, 'Dr. Anup Khetan', 'MBBS, MD - General Medicine, DNB - Cardiology', 'Interventional Cardiologist, General Physician', '124, E.M.Bypass, Santhoshpur, Near Santoshpur Connector, Kolkata', 'Rabindranath Tagore International Institute of Car', '', 'Mon-Sat', '9:00 AM - 7:00 PM', 600, ''),
(22, ' Dr. Dev Roy', 'FRCS - Otolaryngology, MS - ENT,(DLO), MBBS,  Reconstructive surgery', 'ENT/ Otorhinolaryngologist, Pediatric, Otologist/ Neurotologist', '730, Eastern Metropolitan Bypass, Anandapur, Near Ruby, Kolkata', 'Fortis Hospital ', '', 'Tue, Fri', '3:30 PM - 4:30 PM', 900, ''),
(23, ' Dr. Aneek Bhattacharya', 'MBBS, Diploma in Otorhinolaryngology (DLO)', 'ENT/ Otorhinolaryngologist', '730, Eastern Metropolitan Bypass, Anandapur, Near Ruby, Kolkata', 'Fortis Hospital - Anandapur', '', 'Mon-Sat', '12:00 PM - 1:00 PM', 900, ''),
(24, ' Dr. Kallol Paul', 'MBBS, Diploma in Otorhinolaryngology (DLO)', 'ENT/ Otorhinolaryngologist', '2/7, Sarat Bose Road, Beside Central Plaza Building, Kolkata', 'Fortis Medical Centre', '', 'Mon-Sat', '10:30 AM - 12:30 PM', 800, ''),
(25, 'Dr. Subidita Chatterjee', 'MBBS, DGO, DNB - Obstetrics & Gynecology', 'Gynecologist, Obstetrician, Infertility Specialist', 'CF-391, Sector 1 Salt Lake, Near Purto Bhavan, Kolkata', '', 'Body N Mind Cafe', 'Tue-Sat', '10:00 AM - 7:30 PM', 1000, ''),
(26, ' Dr. Dhruba Ray', 'MBBS, DGO, FICS, MD - Obstetrics & Gynaecology', 'Gynecologist, Obstetrician', '730, Eastern Metropolitan Bypass, Anandapur, Near Ruby, KOlkata', 'Fortis Hospital - Anandapur', '', 'Mon', '11:00 AM - 12:00 PM', 800, ''),
(27, 'Dr. Anindita Chakraborty', 'MBBS, MS - Obstetrics & Gynaecology, DGO', 'Gynecologist', '1, Mall Road, Dum Dum, Near Nager Bazar Flyover, Kolkata', 'ILS Hospitals', '', 'On Call', '', 500, ''),
(28, ' Dr. Arindam Rath', 'MBBS, MS - Obstetrics & Gynaecology', 'Gynecologist, Infertility Specialist, Obstetrician', '1/1A, P. S. Pace II, Mahendra Roy Lane, Near Park Circus, Kolkata', 'Nova IVI Fertility', '', 'Mon-Sat', '11:00 AM - 4:00 PM', 1210, '08048885859'),
(29, ' Dr. Ranjit Chakraborti', 'MBBS, DGO, DNB', 'Gynecologist', '730, Eastern Metropolitan Bypass, Anandapur, Near Ruby, Kolkata', 'Fortis Hospital - Anandapur', '', 'Wed, Fri', '10:00 AM - 12:00 PM', 1200, '08048885819'),
(30, 'Dr. Sujata Datta', 'MBBS, MRCOG(UK), FRCOG (UK)', 'Gynecologist', '730, Eastern Metropolitan Bypass, Anandapur, Near Ruby, Kolkata', 'Fortis Hospital - Anandapur', '', 'Mon', '4:00 PM - 6:00 PM', 900, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`d_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
