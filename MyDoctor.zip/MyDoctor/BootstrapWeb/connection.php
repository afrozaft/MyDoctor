<?php 
$db = mysqli_connect("localhost","root","","mydatabase");
if($db)
{
	print "";
}
else
{
	print "Please Check Your Connection!";
}
?>