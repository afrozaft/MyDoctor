-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2019 at 06:55 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE `clinic` (
  `clinic_id` int(11) NOT NULL,
  `cname` text NOT NULL,
  `caddress` varchar(100) NOT NULL,
  `cdoctor` text NOT NULL,
  `ccontact` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinic`
--

INSERT INTO `clinic` (`clinic_id`, `cname`, `caddress`, `cdoctor`, `ccontact`) VALUES
(3, ' Teeth Care Multispeciality Dental Clinic', 'B-1, New Town Metro Plaza, Rajarhat Road, Chinnar Park, Aatghara, Kolkata', ' Dr. Sanket Chakraverty', '033 4058 9379'),
(4, ' Fortis Hospital - Anandapur', '730, Eastern Metropolitan Bypass, Anandapur\r\nNear Ruby, kolkata', ' Dr. Prithwiraj Bhattacharjee', ''),
(5, ' Teeth And Gums Dental Clinic', 'BE-81, (Ground Floor) Sector-1, Bidhannagar,  Near CAP Camp Island & Swimming Pool, Kolkata', 'Dr. Rohini Gupta', ''),
(6, ' Uro Square', '12-D, Krishnakunja Apartment, 1st Floor, Ballygunge Station Road, Kolkata', ' Dr. Ranjan Kumar Dey', '033 4058 7430'),
(7, ' 3D Dental Implant Clinic', '610, 1st Floor, Purbachal Crossing, Near Anwar-sah EM-Bypass Connector,Kolkata', 'Dr. Sandeep Kumar Mitra', '033 4058 6594'),
(8, 'Smile & Care Super Speciality Dental Clinic', '11C/1A, Chetla Central Road, Opposite to Ahindra Mancha, Kolkata', 'Dr. Soumya Bandhopadhyay', '033 4058 6227'),
(9, ' Indopath Clinical Pvt. Ltd.', '87,Near Elgin Road & P.C. Chandra Jewellers, Kolkata', ' Mr. Anant Agarwal', '033 4058 6227'),
(10, 'Chanda Dental Clinic', '70C, Bhupendra Bose Ave, Bidhan Sarani,Shyambazar Metro Station Gate Number 3,Kolkata', 'Dr. Supratim Chanda', '033 4058 6227'),
(11, ' Pearly Whites Dental Clinic', '15, 2nd Floor, Paul Mansion, 6 Bishop Lefroy Road, Landmark: Near Lee Banquets & Brand Factory, Kolk', ' Dr. Aditya Shahabadi', '033 4058 6572'),
(12, ' Dentotsav Dental Clinic', '55, Shantipally, Rajdanga, Near Acropolis - Siemens, Opposite DPS, Kolkata', ' Dr. Anushree Agrawal', '033 7117 2059'),
(13, ' Portea Home Healthcare', 'Flat Number 303/304, Shubham Tower, 3rd Floor, 1 Sarojini Naidu Sarani, Bhagirathi,Kolkata', ' Dr. Debarshi Das (PT)', '033 4058 9203'),
(14, ' Rising Sun Nutrition Clinic', 'P-400 B, 2nd Floor, Keyatala Lane, Near Golpark Petrol Pump & Gariahat, Kolkata', 'Ms. Rina Datta', '033 4058 6572'),
(15, 'Being Dentist Maxillofacial and Dental Implants Clinic', 'P250-B ,First Floor,Cit Road Sch-vi (m), Kankurgachi Kolkata', 'Dr. Saurabh Gupta', '033 4058 9027');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clinic`
--
ALTER TABLE `clinic`
  ADD PRIMARY KEY (`clinic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clinic`
--
ALTER TABLE `clinic`
  MODIFY `clinic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
