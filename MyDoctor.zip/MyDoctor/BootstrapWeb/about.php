<?php 
include "connection.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>About us</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	<link rel="icon" href="d.png" type="image/gif/png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
	<style>
			body{
			background-color: lightblue;
		}
		nav{
			margin-bottom: 20px;
		}
		#logo{
			font-size: 40px;
			margin-right: 40px;
			font-family:  serif;
			
		}
		nav a{
			font-size: 20px;
			margin-left: 20px;
		}
		*{
			margin: 0;
			padding: 0;
			
			font-family: 'Courgette', sans-serif;
		}
		#main-img{
	background-image:linear-gradient(rgba(0,115,153,0.5),rgba(0,115,153,0.5)),url(c2.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	
	
    width: 100%;
    
	height: 100vh;

}

#recommended{
	margin-bottom: 50px;
}
.card{
			width:300px; 
			height:350px;
			border-radius: 25px;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

		}


	</style>

</head>
<body>
	<header>
	<!-- Header of the page -->
	<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
		  <a class="navbar-brand" id="logo" href="index.php" style="color: #0F82FF;">My<span><img src="d.png"></span>Doctor.com</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav mx-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="doctor.php">Doctors</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="clinic.php">Clinics</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="diagnostic.php">Diagnostics</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact.php">Contact us</a>
		      </li>
		      <li class="nav-item active">
		        <a class="nav-link" href="about.php">About us<span class="sr-only">(current)</span></a>
		      </li>
		    </ul>
		    <form class="form-inline my-2 my-lg-0">
		      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
		      <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
		    </form>
		  </div>
  </nav>
		
	</header>

	<main>
		<div class="img-fluid" id="main-img">
			
		</div>

		

    <section><!-- About Us -->
		<div class="container-fluid">
			<h1 class="text-center text-capitalize pt-5">About Us</h1>
			<hr class="w-25 mx-auto pt-5">

			<div class="row mb-5 text-center" id="about">
				
				<div class="col-lg-6 col-md-6 col-sm-6 col-6 mx-auto">
					
					<h4 style="line-height: 50px;">We Live in era of emerging technology in this era every day technology is growing, not only growing vast growing. Everything comes in form of some live internet application. And our daily life effected by these things. And our aim is to connect the world to this technology. The basics idea of this project is that we will design an interface (i.e. Website). This interface has lot of specification such as nearby Clinics, find best Specialist Doctor, find nearby Diagnosis centre for which is helpful for visitor find the with the use of some devices such as Computer, Laptop & Smart Phone or Tab by visiting our Website.</h4><br>
					<a href="contact.php"><button class="btn btn-primary">Contact us</button></a>
				</div>
				
			</div>
			
		</div>    	


    </section><br><br>



		<?php include "links.php"?>


	<section><!-- Gallery -->
    	<div class="container">
			<h1 class="text-center text-capitalize pt-5">Our Team Members</h1>
			<hr class="w-25 mx-auto pt-5">
           <div class="row">
           		<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card" style="border-radius: 50px;">
				    <i class="card-img-top rounded-circle mx-auto pt-5 fas fa-user fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Afroz Alam</h4>
				      
				      <p class="card-text">Shibpur, Howrah, West Bengal</p>
				      <p class="card-text">+91 8910502179</p>
				     
				     
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card" style="border-radius: 50px;">
				    <i class="card-img-top rounded-circle mx-auto pt-5 fas fa-user fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Shakeeb Arsalan</h4>
				      
				      <p class="card-text">Topsia, Kolkata, West Bengal</p>
				      <p class="card-text">+91 9113721681</p>
				     
				     
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>
           	<div class="col-lg-4 col-md-4 col-12 mb-4">
           		<!-- Card Start-->
				  <div class="container">
				 
				  <div class="card" style="border-radius: 50px;">
				    <i class="card-img-top rounded-circle mx-auto pt-5 fas fa-user fa-6x" style="width:30%"><hr></i>
				    <div class="card-body text-center">
				      <h4 class="card-title">Imran Hussain</h4>
				      
				      <p class="card-text">Naihati, Kolkata, West Bengal</p>
				      <p class="card-text">+91 7003963031</p>
				    </div>
				  </div>
				</div>
				<!-- Card End -->
           	</div>


           </div>
       </div>
   </section>


	</main>

<footer>
	<?php include "footer.php"?>
</footer>
	  



	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>	